package org.firstinspires.ftc.teamcode;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp
public class PS_TeleOp extends LinearOpMode{
    private DcMotor frontLeft;
    private DcMotor backLeft;
    private DcMotor frontRight;
    private DcMotor backRight;
    private DcMotorEx g;
    private CRServo thing;
    @Override public void runOpMode() {
        boolean t=false;
        double thingPower = 0;
        int intakeState = 0;
        double frontLeftPower, frontRightPower, backLeftPower,
            backRightPower, gPower;
        
        frontLeft = hardwareMap.get(DcMotor.class, "motor1");
        backLeft = hardwareMap.get(DcMotor.class, "motor2");
        frontRight = hardwareMap.get(DcMotor.class, "motor3");
        backRight = hardwareMap.get(DcMotor.class, "motor4");
        g = hardwareMap.get(DcMotorEx.class, "g");
        thing = hardwareMap.get(CRServo.class, "thing");
        
        frontRight.setDirection(DcMotor.Direction.REVERSE);
        backRight.setDirection(DcMotor.Direction.REVERSE);
        
        resetEncoders();
        
        waitForStart();
        while (opModeIsActive()) {
        // Drive
        // double frontRightPower = gamepad1.right_stick_y - gamepad1.right_stick_x;
        // double frontLeftPower = gamepad1.left_stick_y - gamepad1.left_stick_x;
        // double backRightPower = gamepad1.right_stick_y + gamepad1.right_stick_x;
        // double backLeftPower = gamepad1.left_stick_y + gamepad1.left_stick_x;
        final double driveSpeedFactor = 0.7;
        final double armPowerFactor = 1;
        
        frontLeftPower = driveSpeedFactor * ((gamepad1.left_stick_y + gamepad1.right_stick_y) - (gamepad1.left_stick_x) - gamepad1.right_stick_x);
        frontRightPower = driveSpeedFactor * ((gamepad1.left_stick_y + gamepad1.right_stick_y) + (gamepad1.left_stick_x) + gamepad1.right_stick_x);
        backLeftPower = driveSpeedFactor * ((gamepad1.left_stick_y + gamepad1.right_stick_y) - (gamepad1.left_stick_x) + gamepad1.right_stick_x);
        backRightPower = driveSpeedFactor * ((gamepad1.left_stick_y + gamepad1.right_stick_y) + (gamepad1.left_stick_x) - gamepad1.right_stick_x);
        gPower = armPowerFactor * ((gamepad1.right_trigger-gamepad1.left_trigger)/2);
        
        frontLeft.setPower(frontLeftPower);
        backLeft.setPower(backLeftPower);
        frontRight.setPower(frontRightPower);
        backRight.setPower(backRightPower);
            
        // Control intake
    // Control intake with buttons
        // A: Intake
        // X: Outtake
        // B: Stop intake/outtake

        // Three intakeState flags:
          // 0 = no power
          // 1 = pull in
          // 2 = push out
        switch (intakeState) {
             case 0:
                thingPower = 0;
                break;
             case 1:
                thingPower = 1;
                break;
             case 2:
                thingPower = -1;
                break;
        }
        // Use gamepad1 buttons to change intake states
        if (gamepad1.b == true)
            intakeState = 0;
        else if (gamepad1.a == true)
            intakeState = 1;
        else if (gamepad1.x == true)
            intakeState = 2;
        
        if (gamepad1.y == true) {
         
           g.setTargetPosition(450);
            g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
            g.setVelocity(700);
        }
        if (gamepad1.right_bumper==true) {
            resetEncoders();
            
        }
        
        
        // Arm motor power
        // g.setPower(gPower);
        if (gamepad1.right_trigger > 0 || gamepad1.left_trigger > 0) {
            if((g.getCurrentPosition()<250 && gamepad1.left_trigger >0) || (g.getCurrentPosition()>1830 && gamepad1.right_trigger>0)) {
              //  g.setPower(-0.0002*g.getCurrentPosition()*gPower); (make continuous later) hi DJ DIAPER
                g.setPower(-0.00015*gPower);
                
            }
            else 
            g.setPower(gPower);
        }
            
            
        else if (gamepad1.right_trigger == 0 && gamepad1.left_trigger == 0 && g.getCurrentPosition() > 1000)
            g.setPower(-0.14);
        else if (gamepad1.right_trigger == 0 && gamepad1.left_trigger == 0 && g.getCurrentPosition() < 1000)
            g.setPower(0.14);
        
        // Intake power
        thing.setPower(thingPower);
        if (gamepad1.left_bumper==true) {
            g.setTargetPosition(120);
            g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
            g.setVelocity(500);
            sleep(100);
        }
        if (gamepad1.dpad_up==true) {
             g.setTargetPosition(750);
        g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        g.setVelocity(500);
        sleep(100);
        }
        if (g.getCurrentPosition() < -550) {
            intakeState = 1;
        }
      
        if (gamepad1.right_trigger > 0 || gamepad1.left_trigger > 0)
            g.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            
        telemetry.addData("Arm position", g.getCurrentPosition());
        telemetry.update();
        }
    }
    public void tankkkkkkkk() {
    }
    public void intakeControl() {
    }
    public void scoreSmall(){
        resetEncoders();
        g.setTargetPosition(350);
        g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        g.setVelocity(500);
    }
    public void scoreMedium() {
        resetEncoders();
        g.setTargetPosition(750);
        g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        g.setVelocity(500);
        sleep(100);
    }
    public void grabCone(){
        resetEncoders();
        g.setTargetPosition(-1764);
        g.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        g.setVelocity(500);
    }
    public void resetEncoders() {
        // Resets Encoders
        g.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        g.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        g.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        g.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    }
}
